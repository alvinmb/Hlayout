"""Gerber Export Sets tool -- Tools > Gerber Export Sets...

A job table (name, layers, output prefix) persisted into the current
design's technology file (hlayout.io.techfile.load_gerber_export_jobs()/
save_gerber_export_jobs(), the same tech_params-blob pattern DRC rules
and mask-op batch steps use -- see hlayout.gui.drc_window/
hlayout.gui.maskop_window), plus an Export All button that runs every
job against the current cell via Session.run_gerber_export_batch() and
lists the files each job wrote.

Unlike the mask-op batch window, job ORDER doesn't matter here -- a
Gerber export never modifies the design, it only writes files, so one
job's output can never depend on another's the way a mask-op step's
result_layer can feed a later step. There's accordingly no Move Up/
Move Down here, unlike hlayout.gui.maskop_window.

There's no separate single-shot File/Tools > Export Gerber... command
any more -- "Quick Export (All Layers)..." on this window's toolbar
covers that same one-off case (prompts for an output prefix, exports
every visible layer with data, no saved job needed) so this one window
covers both the quick one-off export and a repeatable saved set (e.g.
one job per fab house) you can re-run together with Export All.
"""

import os
import tkinter as tk
from tkinter import filedialog, ttk

from . import dialogs
from .fonts import section_header_font
from ..core.errors import LayoutError
from ..io import toolsets
from ..io.techfile import GERBER_JOBS_KEY, GERBER_OUTPUT_DIR_KEY, GERBER_SCALE_KEY
from ..io.gerberio import (GerberExportJob, check_gerber_scale,
                           default_gerber_output_dir, resolve_out_prefix)


def _layer_label(library, number):
    return f"{number} ({library.layers[number].name})"


class JobDialog(tk.Toplevel):
    """Modal Add/Edit form for one Gerber export job."""

    def __init__(self, parent, library, job: GerberExportJob = None, initial_dir=None):
        super().__init__(parent)
        self.title("Add Gerber Export Job" if job is None else "Edit Gerber Export Job")
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        self.library = library
        self.initial_dir = initial_dir
        self.result = None
        self._build(job)
        self.bind("<Escape>", lambda e: self.destroy())

    def _build(self, job):
        form = ttk.Frame(self, padding=16)
        form.pack(fill="both", expand=True)

        ttk.Label(form, text="Name:").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        self.name_var = tk.StringVar(value=job.name if job else "")
        ttk.Entry(form, textvariable=self.name_var, width=28).grid(
            row=0, column=1, columnspan=2, sticky="w", padx=4, pady=4)

        ttk.Label(form, text="Output prefix:").grid(row=1, column=0, sticky="e", padx=4, pady=4)
        self.prefix_var = tk.StringVar(value=job.out_prefix if job else "")
        ttk.Entry(form, textvariable=self.prefix_var, width=28).grid(
            row=1, column=1, sticky="w", padx=4, pady=4)
        ttk.Button(form, text="Browse...", command=self._browse).grid(
            row=1, column=2, sticky="w", padx=4, pady=4)

        ttk.Label(form, text="(files are written as <prefix>_L<NN>_<layer name>.gbr;\n"
                             "a plain name goes into the window's Output folder)",
                  foreground="#888888", justify="left").grid(
            row=2, column=0, columnspan=3, sticky="w", padx=4)

        self.all_layers_var = tk.BooleanVar(value=job is None or not job.layers)
        ttk.Checkbutton(
            form, text="All visible layers with data", variable=self.all_layers_var,
            command=self._sync,
        ).grid(row=3, column=0, columnspan=3, sticky="w", padx=4, pady=(10, 0))

        ttk.Label(form, text="Layers:").grid(row=4, column=0, sticky="ne", padx=4, pady=4)
        list_frame = ttk.Frame(form)
        list_frame.grid(row=4, column=1, columnspan=2, sticky="w", padx=4, pady=4)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical")
        self.layer_list = tk.Listbox(
            list_frame, selectmode="multiple", height=10, width=28,
            exportselection=False, yscrollcommand=scrollbar.set,
        )
        scrollbar.config(command=self.layer_list.yview)
        self.layer_list.pack(side="left", fill="y")
        scrollbar.pack(side="left", fill="y")
        selected_layers = set(job.layers) if job and job.layers else set()
        for n in range(len(self.library.layers)):
            self.layer_list.insert("end", _layer_label(self.library, n))
            if n in selected_layers:
                self.layer_list.selection_set(n)

        self.error_var = tk.StringVar(value="")
        ttk.Label(form, textvariable=self.error_var, foreground="red", wraplength=340,
                  justify="left").grid(row=5, column=0, columnspan=3, sticky="w", padx=4, pady=(6, 0))

        btn_row = ttk.Frame(self)
        btn_row.pack(pady=(0, 12))
        ttk.Button(btn_row, text="OK", command=self._accept).pack(side="left", padx=6)
        ttk.Button(btn_row, text="Cancel", command=self.destroy).pack(side="left", padx=6)

        self._sync()

    def _sync(self):
        self.layer_list.configure(state="disabled" if self.all_layers_var.get() else "normal")

    def _browse(self):
        path = filedialog.asksaveasfilename(
            title="Gerber Output Prefix", defaultextension="",
            filetypes=[("All files", "*.*")], parent=self,
            initialdir=self.initial_dir,
        )
        if path:
            # A prefix picked inside the Output folder is kept RELATIVE to
            # it, so the job follows the folder if that is changed later.
            if self.initial_dir:
                try:
                    rel = os.path.relpath(path, self.initial_dir)
                except ValueError:  # different drive
                    rel = None
                if rel and not rel.startswith(".."):
                    path = rel
            self.prefix_var.set(path)

    def _accept(self):
        name = self.name_var.get().strip()
        prefix = self.prefix_var.get().strip()
        if not prefix:
            self.error_var.set("Pick an output prefix.")
            return
        layers = None
        if not self.all_layers_var.get():
            layers = [int(i) for i in self.layer_list.curselection()]
            if not layers:
                self.error_var.set("Pick at least one layer, or check 'All visible layers with data'.")
                return
        try:
            job = GerberExportJob(name=name, out_prefix=prefix, layers=layers)
        except LayoutError as e:
            self.error_var.set(str(e))
            return
        self.result = job
        self.destroy()


class GerberBatchWindow(tk.Toplevel):
    """Tools > Gerber Export Sets... . `library` is the current
    design's Library; jobs are loaded from it on open and persisted
    back into it immediately on every add/edit/delete. `app` is the
    main App (used to run the batch against the live session)."""

    def __init__(self, master, library, app=None):
        super().__init__(master)
        self.title("Gerber Export Sets")
        self.geometry("1000x700")
        self.library = library
        self.app = app
        # A design with no jobs of its own starts from the last-used set
        # rather than an empty table (see hlayout.io.toolsets).
        toolsets.seed_from_last_used(library, GERBER_JOBS_KEY,
                                     transform=toolsets.gerber_jobs_for_another_design)
        self.jobs = [GerberExportJob.from_dict(j) for j in _load_jobs(library)]
        self._build()
        self._refresh_jobs()
        self.bind("<Escape>", lambda e: self.destroy())

    def _build(self):
        toolbar = ttk.Frame(self, padding=6)
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="Add Job...", command=self._add_job).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Edit Job...", command=self._edit_job).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Delete Job", command=self._delete_job).pack(side="left", padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(toolbar, text="Run All Jobs", command=self._run_batch).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Quick Export (All Layers)...",
                   command=self._quick_export).pack(side="left", padx=2)

        ttk.Label(toolbar, text="Apply to:").pack(side="left", padx=(16, 2))
        self.scope_var = tk.StringVar(value="Current cell")
        cell_names = list(self.library.cells.keys())
        ttk.Combobox(toolbar, textvariable=self.scope_var, state="readonly", width=18,
                     values=["Current cell"] + cell_names).pack(side="left", padx=2)

        ttk.Button(toolbar, text="Close", command=self.destroy).pack(side="right", padx=2)
        ttk.Button(toolbar, text="About", command=self._about).pack(side="right", padx=2)

        # Output folder for the whole set: defaults to <current dir>/Gerber
        # (next to the open design), editable, remembered with the design.
        out_row = ttk.Frame(self, padding=(6, 0, 6, 4))
        out_row.pack(fill="x")
        ttk.Label(out_row, text="Output folder:").pack(side="left", padx=(2, 4))
        self.out_dir_var = tk.StringVar(value=self._initial_out_dir())
        self.out_dir_entry = ttk.Entry(out_row, textvariable=self.out_dir_var)
        self.out_dir_entry.pack(side="left", fill="x", expand=True, padx=2)
        self.out_dir_entry.bind("<FocusOut>", lambda e: self._out_dir_changed())
        self.out_dir_entry.bind("<Return>", lambda e: self._out_dir_changed())
        ttk.Button(out_row, text="Browse...", command=self._browse_out_dir).pack(side="left", padx=2)
        ttk.Button(out_row, text="Default", command=self._reset_out_dir).pack(side="left", padx=2)

        # Artwork scale for the whole set: hybrid screen artwork is
        # normally plotted at 5X or 10X. Remembered with the design.
        ttk.Label(out_row, text="Scale:").pack(side="left", padx=(14, 2))
        self.scale_var = tk.StringVar(value=_scale_label(_load_scale(self.library)))
        self.scale_combo = ttk.Combobox(out_row, textvariable=self.scale_var, width=6,
                                        values=["1X", "5X", "10X"])
        self.scale_combo.pack(side="left", padx=2)
        self.scale_combo.bind("<<ComboboxSelected>>", lambda e: self._scale_changed())
        self.scale_combo.bind("<FocusOut>", lambda e: self._scale_changed())
        self.scale_combo.bind("<Return>", lambda e: self._scale_changed())

        body = ttk.Panedwindow(self, orient="vertical")
        body.pack(fill="both", expand=True, padx=4, pady=4)

        section_font = section_header_font(self)

        top = ttk.Frame(body)
        ttk.Label(top, text="JOBS", foreground="#3fb950",
                  font=section_font).pack(anchor="w", padx=4, pady=(4, 0))
        job_cols = ("name", "layers", "prefix")
        self.job_table = ttk.Treeview(top, columns=job_cols, show="headings", height=8)
        for col, heading, width in [
            ("name", "Name", 140), ("layers", "Layers", 260), ("prefix", "Output prefix", 400),
        ]:
            self.job_table.heading(col, text=heading)
            self.job_table.column(col, width=width, anchor="w")
        self.job_table.pack(fill="both", expand=True, padx=4, pady=4)
        body.add(top, weight=1)

        bottom = ttk.Frame(body)
        ttk.Label(bottom, text="FILES WRITTEN", foreground="#f78166",
                  font=section_font).pack(anchor="w", padx=4, pady=(4, 0))
        result_cols = ("job", "layer", "file")
        self.result_table = ttk.Treeview(bottom, columns=result_cols, show="headings", height=12)
        for col, heading, width in [
            ("job", "Job", 140), ("layer", "Layer", 100), ("file", "File", 460),
        ]:
            self.result_table.heading(col, text=heading)
            self.result_table.column(col, width=width, anchor="w")
        self.result_table.pack(fill="both", expand=True, padx=4, pady=4)
        body.add(bottom, weight=2)

        status = ttk.Frame(self, padding=(6, 3))
        status.pack(fill="x")
        self.status_var = tk.StringVar(value="")
        ttk.Label(status, textvariable=self.status_var, foreground="#8b949e").pack(side="left")

    # -- jobs --------------------------------------------------------------
    def _refresh_jobs(self):
        self.job_table.delete(*self.job_table.get_children())
        for i, job in enumerate(self.jobs):
            layer_desc = ("all visible layers" if not job.layers
                          else ", ".join(str(n) for n in job.layers))
            self.job_table.insert("", "end", iid=str(i), values=(
                job.name, layer_desc, resolve_out_prefix(job.out_prefix, self.output_dir())))
        self.status_var.set(f"{len(self.jobs)} job(s) -- kept with the design between sessions")

    def _persist(self):
        _save_jobs(self.library, self.jobs)
        self._remember()

    def _remember(self):
        """Write the jobs, output folder and scale through to disk now,
        so they survive closing HLayout without saving the design. Only
        the jobs are also kept as the user's last-used set -- an output
        folder or scale belongs to one design."""
        toolsets.remember(
            self.library, [GERBER_JOBS_KEY, GERBER_OUTPUT_DIR_KEY, GERBER_SCALE_KEY],
            app=self.app, last_used_keys=[GERBER_JOBS_KEY])

    def _current_job_row(self):
        sel = self.job_table.selection()
        return int(sel[0]) if sel else -1

    # -- output folder -----------------------------------------------------
    def _default_out_dir(self):
        """<current dir>/Gerber -- beside the open design file, or under
        the working directory for a design that has never been saved."""
        design_path = getattr(self.app, "current_path", None) if self.app is not None else None
        return default_gerber_output_dir(design_path)

    def _initial_out_dir(self):
        return _load_out_dir(self.library) or self._default_out_dir()

    def output_dir(self):
        """The folder jobs are written to: what's in the field, or the
        default when the field is blank."""
        return self.out_dir_var.get().strip() or self._default_out_dir()

    def _out_dir_changed(self):
        value = self.out_dir_var.get().strip()
        if not value:
            value = self._default_out_dir()
            self.out_dir_var.set(value)
        # Only a folder that differs from the default is saved, so a
        # design left on the default keeps following wherever it is saved.
        same = os.path.normcase(os.path.normpath(value)) == \
            os.path.normcase(os.path.normpath(self._default_out_dir()))
        before = _load_out_dir(self.library)
        _save_out_dir(self.library, "" if same else value)
        if _load_out_dir(self.library) != before:
            self._remember()
        self._refresh_jobs()

    def _browse_out_dir(self):
        start = self.output_dir()
        while start and not os.path.isdir(start):
            parent = os.path.dirname(start)
            if parent == start:
                break
            start = parent
        path = filedialog.askdirectory(title="Gerber Output Folder", parent=self,
                                       initialdir=start or None, mustexist=False)
        if path:
            self.out_dir_var.set(os.path.normpath(path))
            self._out_dir_changed()

    def _reset_out_dir(self):
        self.out_dir_var.set(self._default_out_dir())
        self._out_dir_changed()

    def _default_dir(self):
        return self.output_dir()

    # -- artwork scale -----------------------------------------------------
    def scale(self):
        """The artwork scale in the Scale box as a number ("5X" -> 5.0).
        Raises LayoutError if it isn't a positive number."""
        return check_gerber_scale(self.scale_var.get().strip().rstrip("xX").strip() or "1")

    def _scale_changed(self):
        try:
            value = self.scale()
        except LayoutError as e:
            self.status_var.set(str(e))
            return False
        self.scale_var.set(_scale_label(value))
        changed = GERBER_SCALE_KEY not in self.library.tech_params or \
            _load_scale(self.library) != value
        _save_scale(self.library, value)
        if changed:
            self._remember()
        return True

    def _add_job(self):
        dlg = JobDialog(self, self.library, initial_dir=self._default_dir())
        self.wait_window(dlg)
        if dlg.result is not None:
            self.jobs.append(dlg.result)
            self._persist()
            self._refresh_jobs()

    def _edit_job(self):
        row = self._current_job_row()
        if row < 0:
            dialogs.show_info("Edit Job", "Select a job first.", parent=self)
            return
        dlg = JobDialog(self, self.library, job=self.jobs[row], initial_dir=self._default_dir())
        self.wait_window(dlg)
        if dlg.result is not None:
            self.jobs[row] = dlg.result
            self._persist()
            self._refresh_jobs()

    def _delete_job(self):
        row = self._current_job_row()
        if row < 0:
            dialogs.show_info("Delete Job", "Select a job first.", parent=self)
            return
        del self.jobs[row]
        self._persist()
        self._refresh_jobs()

    # -- run -----------------------------------------------------------------
    def _run_batch(self):
        if self.app is None:
            dialogs.show_info("Export All", "This window isn't attached to a layout window.",
                               parent=self)
            return
        if not self.jobs:
            dialogs.show_info("Export All", "Add at least one job first.", parent=self)
            return
        scope = self.scope_var.get()
        cell_name = None if scope == "Current cell" else scope
        try:
            self._out_dir_changed()  # pick up a typed-but-not-yet-committed folder
            scale = self.scale()
            self._scale_changed()
            results = self.app.session.run_gerber_export_batch(
                self.jobs, cell_name=cell_name, out_dir=self.output_dir(), scale=scale)
        except (LayoutError, OSError) as e:
            dialogs.show_error("Export All", str(e), parent=self)
            return
        self.result_table.delete(*self.result_table.get_children())
        total_files = 0
        total_skipped = 0
        row = 0
        for job, written, skipped_text in results:
            label = job.name or job.out_prefix
            written_ns = [n for n, _ in written]
            if not written:
                # An explicitly-requested layer (job.layers) is exported
                # regardless of Setup > Layers visibility (write_gerber_
                # layers() only gates the implicit "all visible" default),
                # so a requested layer missing here genuinely has no data
                # -- not silently vetoed by being hidden on screen.
                desc = ("no data on layer(s) " + ", ".join(str(n) for n in job.layers)
                        if job.layers else "(no visible layer had data)")
                self.result_table.insert("", "end", iid=str(row), values=(label, "", desc))
                row += 1
                continue
            for layer_n, path in written:
                self.result_table.insert("", "end", iid=str(row), values=(
                    label, layer_n, os.path.basename(path)))
                total_files += 1
                row += 1
            if job.layers:
                missing = [n for n in job.layers if n not in written_ns]
                if missing:
                    self.result_table.insert("", "end", iid=str(row), values=(
                        label, ", ".join(str(n) for n in missing), "(no data on this layer)"))
                    row += 1
            total_skipped += skipped_text
        note = f", {total_skipped} text shape(s) skipped (Gerber has no text primitive)" if total_skipped else ""
        self.status_var.set(
            f"Run All Jobs: {len(results)} job(s) run, {total_files} file(s) written{note}"
            f" at {scale:g}X -- output folder {self.output_dir()}")

    def _quick_export(self):
        """One-off export of every visible layer with data, prompting
        for just an output prefix -- no saved job needed. Covers the
        same case the old single-shot File/Tools > Export Gerber...
        dialog did, without leaving anything behind in the JOBS table
        (unless you separately choose Add Job...)."""
        if self.app is None:
            dialogs.show_info("Quick Export", "This window isn't attached to a layout window.",
                               parent=self)
            return
        path = filedialog.asksaveasfilename(
            title="Export Gerber", defaultextension="",
            filetypes=[("All files", "*.*")],
            initialfile=self.library.name, initialdir=self._default_dir(), parent=self,
        )
        if not path:
            return
        scope = self.scope_var.get()
        cell_name = None if scope == "Current cell" else scope
        try:
            scale = self.scale()
            written, skipped_text = self.app.session.export_gerber(
                path, cell_name=cell_name, scale=scale)
        except (LayoutError, OSError) as e:
            dialogs.show_error("Quick Export failed", str(e), parent=self)
            return
        if not written:
            dialogs.show_info("Quick Export", "No visible layers had any data to export.", parent=self)
            return
        names = "\n".join(f"  L{n}: {os.path.basename(p)}" for n, p in written)
        note = (f"\n\n{skipped_text} text shape(s) were skipped -- "
                f"Gerber has no text primitive." if skipped_text else "")
        dialogs.show_info("Quick Export",
                          f"Wrote {len(written)} file(s) at {scale:g}X:\n{names}{note}",
                          parent=self)
        self.status_var.set(f"Quick Export: wrote {len(written)} file(s) to {os.path.dirname(path) or '.'}")

    def _about(self):
        dialogs.show_info(
            "About",
            "Gerber Export Sets\n\n"
            "A saved set of Gerber export jobs -- each with its own "
            "layer subset and output prefix -- run together as one "
            "action, e.g. one job per fab house or board revision.\n\n"
            "Output folder: where the set is written. It defaults to a "
            "Gerber folder beside the open design. A job whose prefix "
            "is a plain name goes into it; a job with a full path keeps "
            "its own location.\n\n"
            "Scale: the artwork scale for every job and for Quick "
            "Export -- 1X is actual size; hybrid screen artwork is "
            "usually plotted at 5X (the default) or 10X. Coordinates and line widths "
            "are enlarged about the design origin; the design itself "
            "is not changed.\n\n"
            "Unlike Tools > Mask Operation Batch..., job order doesn't "
            "matter: a Gerber export never modifies the design, it "
            "only writes files, so one job never depends on another's "
            "output.\n\n"
            "Jobs are saved into this design's technology file "
            "(Setup > Save Technology File...).",
            parent=self,
        )


def _load_jobs(library):
    from ..io.techfile import load_gerber_export_jobs
    return load_gerber_export_jobs(library)


def _save_jobs(library, jobs):
    from ..io.techfile import save_gerber_export_jobs
    save_gerber_export_jobs(library, jobs)


def _load_out_dir(library):
    from ..io.techfile import load_gerber_output_dir
    return load_gerber_output_dir(library)


def _save_out_dir(library, path):
    from ..io.techfile import save_gerber_output_dir
    save_gerber_output_dir(library, path)


def _load_scale(library):
    from ..io.techfile import load_gerber_scale
    return load_gerber_scale(library)


def _save_scale(library, scale):
    from ..io.techfile import save_gerber_scale
    save_gerber_scale(library, scale)


def _scale_label(scale):
    return f"{scale:g}X"


def open_gerber_batch_window(app):
    """Tools > Gerber Export Sets... . Reuses a single window per App
    instance -- calling this again while one is already open just
    brings it to the front, instead of stacking up duplicates."""
    win = getattr(app, "_gerber_batch_window", None)
    if win is not None and win.winfo_exists():
        win.lift()
        win.focus_set()
        return win
    win = GerberBatchWindow(app, app.session.library, app=app)
    app._gerber_batch_window = win
    return win
