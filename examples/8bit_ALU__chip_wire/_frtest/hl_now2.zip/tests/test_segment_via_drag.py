"""Dragging a routed track's segment carries the via at its end: the via's
pads on both conductors, its dielectric window, and the tracks meeting it."""
import os
import sys
import types

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

tk = pytest.importorskip("tkinter")


def _app():
    from hlayout.gui.app import App
    from hlayout.core import Library
    from hlayout.io.techfile import (load_dielectric_rules, load_route_rules,
                                     save_dielectric_rules, save_route_rules)
    try:
        lib = Library("SEG")
        top = lib.new_cell("TOP")
        rr = load_route_rules(lib); rr["layer_a"] = 3; rr["layer_b"] = 5
        save_route_rules(lib, rr)
        dr = load_dielectric_rules(lib); dr["layer"] = 4
        save_dielectric_rules(lib, dr)
        app = App(lib)
    except tk.TclError as e:
        pytest.skip(f"no display available: {e}")
    app.update()
    app.snap_var.set(False)
    app._on_snap_change()
    app.mode_var.set("select")
    app._on_mode_change()
    return app, top


def _ev(x, y):
    return types.SimpleNamespace(x=x, y=y)


def _drag(app, a, b):
    c = app.canvas
    c._select_click(_ev(*c.to_px(*a)))
    assert c.selected[0] == "edge"
    c._on_drag_motion(_ev(*c.to_px(*b)))
    c._on_release(_ev(*c.to_px(*b)))


def _centre(sh):
    x0, y0, x1, y1 = sh.bbox()
    return ((x0 + x1) / 2, (y0 + y1) / 2)


def test_segment_drag_carries_the_via_its_window_and_the_other_layers_track():
    app, top = _app()
    try:
        t1 = top.add_path(3, [(0, 0), (10000, 0), (10000, 5000)], 300)
        pads = [top.add_rectangle(lay, 9800, 4800, 10200, 5200) for lay in (3, 5)]
        win = top.add_rectangle(4, 9700, 4700, 10300, 5300)
        t2 = top.add_path(5, [(10000, 5000), (20000, 5000)], 300)          # leaves along the drag
        t3 = top.add_path(5, [(10000, 5000), (10000, 9000), (15000, 9000)], 300)  # leaves across it
        other = top.add_rectangle(5, 30000, 30000, 30400, 30400)          # not at the via
        app.canvas.fit_view()
        app.canvas.redraw()
        _drag(app, (10000, 2500), (12000, 2500))                           # vertical segment, 2 mm right
        assert t1.points == [(0, 0), (12000, 0), (12000, 5000)]
        assert all(_centre(p) == (12000, 5000) for p in pads) and _centre(win) == (12000, 5000)
        assert t2.points == [(12000, 5000), (20000, 5000)]                # just shorter
        assert t3.points == [(12000, 5000), (12000, 9000), (15000, 9000)]  # its leg slid, still square
        assert _centre(other) == (30200, 30200)
        app._undo()                                                        # one undo puts it all back
        assert t1.points == [(0, 0), (10000, 0), (10000, 5000)] or \
            [tuple(p) for p in top.shapes[0].points] == [(0, 0), (10000, 0), (10000, 5000)]
    finally:
        app.destroy()


def test_a_plain_bend_carries_nothing():
    app, top = _app()
    try:
        t1 = top.add_path(3, [(0, 0), (10000, 0), (10000, 5000)], 300)
        t2 = top.add_path(3, [(10000, 5000), (20000, 5000)], 300)          # same layer, no via
        app.canvas.fit_view()
        app.canvas.redraw()
        _drag(app, (10000, 2500), (12000, 2500))
        assert t1.points[-1] == (12000, 5000) and t2.points == [(10000, 5000), (20000, 5000)]
    finally:
        app.destroy()
