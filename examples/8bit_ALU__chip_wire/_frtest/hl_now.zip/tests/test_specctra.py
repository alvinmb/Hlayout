import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

pytest.importorskip("shapely")

from hlayout.core.shapes import Path
from hlayout.io.specctra import (export_dsn, freerouting_command, parse_sexpr, parse_ses,
                                 run_freerouting)
from tests.test_nettrace import _board


def _named(via=True):
    s = _board(via=via)
    s.set_net_names({"IO.1": "SIG", "U1.2": "SIG", "U1.1": "LONE"})
    return s


def test_export_dsn_structure(tmp_path):
    s = _named()
    p = str(tmp_path / "b.dsn")
    summ = s.export_dsn(p)
    txt = open(p).read()
    assert txt.count("(") == txt.count(")")
    tree = parse_sexpr(txt)[0]
    assert tree[0] == "pcb"
    assert "(layer L5 (type signal) (property (index 0)))" in txt     # 2nd conductor on top
    assert "(layer L3 (type signal) (property (index 1)))" in txt
    assert "(snap_angle ninety_degree)" in txt
    assert "(net SIG (pins IO-1 U1-2))" in txt
    assert "(net LONE (pins U1-1))" in txt
    assert "(padstack PAD_L5_400x400 (shape (rect L5 -200 -200 200 200)) (attach off))" in txt
    # the IO pad is offered only as its 0.3 mm inner strip; the rest of it
    # is a netless obstacle set back by the clearance
    assert "(pin PAD_L3_300x800 1 -4550 0)" in txt
    assert "(image IMG_HL_IOREST" in txt and "PAD_L3_400x800" in txt
    # off the dielectric only the 1st conductor may run: band closed to L5
    assert "(image IMG_HL_EDGE" in txt
    assert "(place IO 0 0 front 0)" in txt and "(place U1 1000 0 front 0)" in txt
    assert "(net SIG)(type protect)" in txt                          # existing routing kept
    assert "(via VIA_SIG 4000 0(net SIG)(type protect))" in txt
    assert summ.nets == 2
    assert summ.wires == 2 and summ.vias == 1


def test_export_requires_net_names(tmp_path):
    from hlayout.core.errors import LayoutError
    s = _board()
    with pytest.raises(LayoutError, match="net names"):
        s.export_dsn(str(tmp_path / "x.dsn"))


def test_route_mode_marks_wiring_route(tmp_path):
    s = _named()
    p = str(tmp_path / "b.dsn")
    s.export_dsn(p, keep_existing=False, exclude_nets=["LONE"], power_nets=["SIG"])
    txt = open(p).read()
    assert "(type route)" in txt and "(type protect)" not in txt
    assert "(class HL_POWER SIG" in txt and "(class HL_EXCLUDED LONE" in txt


SES = """(session x
  (base_design x)
  (routes
    (resolution um 10)
    (network_out
      (net SIG
        (wire (path L3 3000 -44000 0 40000 0))
        (via VIA_SIG 40000 0)
        (wire (path L5 3000 40000 0 40000 15000 20000 15000 20000 0))
        (wire (path L5 3000 0 -5000 0 -9000))
        (via VIA_PWR 0 -9000)
      )
    )
  )
)
"""


def test_parse_ses_scales_resolution(tmp_path):
    p = tmp_path / "a.ses"
    p.write_text(SES)
    r = parse_ses(str(p))
    assert r.wires[0] == ("SIG", "L3", 300.0, [(-4400.0, 0.0), (4000.0, 0.0)])
    assert r.vias == [("SIG", "VIA_SIG", 4000.0, 0.0), ("SIG", "VIA_PWR", 0.0, -900.0)]


def test_import_ses_keeps_existing_and_adds_new(tmp_path):
    s = _named(via=False)
    # no via yet, so SIG is open; the session adds it (plus a stub + power via)
    assert s.highlight_net("IO.1").missing == ["U1.2"]
    p = tmp_path / "a.ses"
    p.write_text(SES)
    n_paths = sum(isinstance(x, Path) for x in s.cell.shapes)
    st = s.import_ses(str(p))
    # the L3 wire and the first L5 wire duplicate existing tracks -> skipped
    assert st["wires"] == 1 and st["vias"] == 2 and st["skipped"] == 2
    assert sum(isinstance(x, Path) for x in s.cell.shapes) == n_paths + 1
    win = [x for x in s.cell.shapes if x.layer == 4 and x.datatype == 0
           and (x.bbox()[2] - x.bbox()[0]) in (600, 800)]
    assert len(win) == 2                                          # each via got its window
    assert any(x.layer == 4 and x.datatype == 1 for x in s.cell.shapes)   # fill regenerated
    assert st["nets"] == 1 and st["complete"] == 1 and st["unrouted"] == []
    assert s.undo() is True
    assert sum(isinstance(x, Path) for x in s.cell.shapes) == n_paths


def test_import_ses_replace_mode(tmp_path):
    s = _named()
    p = tmp_path / "a.ses"
    p.write_text(SES)
    st = s.import_ses(str(p), keep_existing=False)
    paths = [x for x in s.cell.shapes if isinstance(x, Path)]
    assert len(paths) == 3 and st["wires"] == 3


def test_freerouting_command_shapes():
    cmd = freerouting_command("C:/fr/freerouting.exe", "a.dsn", "a.ses", passes=7,
                              exclude_classes=["HL_EXCLUDED"])
    assert cmd == ["C:/fr/freerouting.exe", "-de", "a.dsn", "-do", "a.ses", "-mp", "7",
                   "--gui.enabled=false", "-da", "-inc", "HL_EXCLUDED"]
    cmd = freerouting_command("fr.jar", "a.dsn", "a.ses", java=sys.executable)
    assert cmd[:3] == [sys.executable, "-jar", "fr.jar"]
    cmd = freerouting_command("C:/x/freerouting-cli.exe", "a.dsn", "a.ses", passes=50)
    assert cmd[cmd.index("-mp") + 1] == "1" and "-mt" in cmd    # native build: 1 pass only


def test_freerouting_command_sets_route_and_optimize_passes():
    cmd = freerouting_command("fr.exe", "a.dsn", "a.ses", passes=40, optimize_passes=6,
                              optimize_threshold=1.5)
    assert cmd[cmd.index("-mp") + 1] == "40"
    assert "--router.optimizer.max_passes=6" in cmd
    assert "--router.optimizer.improvement_threshold=1.5" in cmd
    cmd = freerouting_command("fr.exe", "a.dsn", "a.ses", passes=0, optimize_passes=0,
                              optimize_threshold=1.5)
    assert cmd[cmd.index("-mp") + 1] == "0"                     # route until done
    assert "--router.optimizer.enabled=false" in cmd
    assert not any("improvement_threshold" in c or "max_passes" in c for c in cmd)


def test_optimize_rules_round_trip():
    s = _named()
    r = s.set_freerouting_rules(passes=0, optimize_passes=12, optimize_threshold=0.5)
    assert (r["passes"], r["optimize_passes"], r["optimize_threshold"]) == (0, 12, 0.5)


def test_run_freerouting_streams_output(tmp_path):
    ses = str(tmp_path / "o.ses")
    code = ("import sys;print('pass 1');print('pass 2');"
            f"open({ses!r},'w').write('(session x)')")
    lines = []
    rc, tail = run_freerouting([sys.executable, "-c", code], ses, timeout=30,
                               on_line=lines.append)
    assert rc == 0 and lines == ["pass 1", "pass 2"] and os.path.exists(ses)


#: verbatim output of Freerouting CLI v2.5.0 for this board (L5 jumper
#: removed so SIG needed routing) -- note it repeats the protected wire
REAL_SES = """(session t
  (base_design t)
  (placement
    (resolution um 1)
    (component "IMG_IO"
      (place IO 0 0 front 0)
    )
    (component "IMG_U1"
      (place U1 1000 0 front 0)
    )
  )
  (was_is
  )
  (routes 
    (resolution um 1)
    (parser
      (host_cad HLayout)
      (host_version "1")
    )
    (library_out 
      (padstack "VIA_SIG"
        (shape
          (rect L5 -200 -200 200 200)
        )
        (shape
          (rect L3 -200 -200 200 200)
        )
        (attach off)
      )
    )
    (network_out 
      (net SIG
        (wire
          (path L5 300
            -4077 -675
            2000 -675
            2000 0
          )
        )
        (wire
          (path L3 300
            -4077 -675
            -4800 -675
            -4800 0
          )
        )
        (via "VIA_SIG" -4077 -675
        )
        (wire
          (path L3 300
            -4400 0
            -4800 0
          )
        )
        (wire
          (path L3 300
            -4400 0
            4000 0
          )
          (type protect)
        )
      )
    )
  )
)
"""


def test_import_real_freerouting_output(tmp_path):
    s = _named(via=False)
    s.cell.shapes[:] = [x for x in s.cell.shapes if not (isinstance(x, Path) and x.layer == 5)]
    p = tmp_path / "real.ses"
    p.write_text(REAL_SES)
    st = s.import_ses(str(p))
    assert st == {"wires": 3, "vias": 1, "skipped": 1, "fingers": 0, "nets": 1, "complete": 1,
                  "unrouted": []}
    assert s.highlight_net("U1.2").pins == ["IO.1", "U1.2"]


# ---------------------------------------------------------------------------
# chip-and-wire (wire-bonded dice, one conductor) -- the notch filter example
# ---------------------------------------------------------------------------

NOTCH = os.path.join(os.path.dirname(__file__), "..", "hlayout", "examples", "notch_filter.gds")


def _notch_stripped():
    """The notch filter with its hand-drawn copper removed and its nets
    named from the original connectivity (bonds included)."""
    from hlayout.io.sidecar import load_design
    from hlayout.scripting.api import Session
    lib = load_design(NOTCH).library
    s = Session(lib)
    names = {}
    for n in s.extract_netlist([3], include_bonds=True):
        if n.id != "UNASSIGNED" and len(n.pins) > 1:
            for p in n.pins:
                names[f"{p.ref_des}.{p.pin}"] = n.id
    s.set_net_names(names)
    top = lib.cells["TOP"]
    top.shapes[:] = [sh for sh in top.shapes if sh.layer != 3]
    return s, names


@pytest.mark.skipif(not os.path.exists(NOTCH), reason="notch filter example not present")
def test_bond_landings_name_the_die_pad_at_the_other_end():
    s, names = _notch_stripped()
    land = s.bond_landings("TOP")
    assert len(land) == 22
    pads = {p for _x, _y, ps in land for p in ps}
    assert "ML1.3" in pads and "J1.19" in pads          # die pad and header pin
    assert all(len(ps) == 1 for _x, _y, ps in land)


@pytest.mark.skipif(not os.path.exists(NOTCH), reason="notch filter example not present")
def test_chip_and_wire_dsn_has_bond_fingers_keepouts_and_one_layer(tmp_path):
    s, _names = _notch_stripped()
    p = str(tmp_path / "n.dsn")
    summ = s.export_dsn(p, cell_name="TOP")
    txt = open(p).read()
    assert txt.count("(") == txt.count(")")
    assert "(layer L3 (type signal)" in txt and "(layer L5" not in txt   # nothing on L5: single layer
    assert txt.count("(pin PAD_L3_400x400 B") == 22                     # a finger per landing
    assert "(image IMG_HL_KEEP" in txt                                   # dice / part bodies
    assert "(clearance 300)" in txt                                      # tightened to the DRC rules
    assert summ.nets == 17
    assert all(not u.startswith("BOND.") for u in summ.unknown_pads)


@pytest.mark.skipif(not os.path.exists(NOTCH), reason="notch filter example not present")
def test_import_lays_bond_fingers_and_counts_landings_in_the_completion_check(tmp_path):
    s, names = _notch_stripped()
    land = s._bond_nets(s.bond_landings("TOP"), names)
    # a fake session: one straight L3 wire per landing to nowhere -- the
    # point is the fingers, so route nothing and check they are laid
    ses = tmp_path / "n.ses"
    ses.write_text("(session n (routes (resolution um 1) (network_out)))\n")
    out = s.import_ses(str(ses), cell_name="TOP")
    assert out["fingers"] == len(land) == 22
    assert out["complete"] < out["nets"]          # nothing routed: fingers alone don't join nets


@pytest.mark.skipif(not os.path.exists(NOTCH), reason="notch filter example not present")
def test_bond_fingers_on_the_2nd_conductor(tmp_path):
    from hlayout.core.shapes import Rectangle
    s, names = _notch_stripped()
    s.set_freerouting_rules(finger_layer="second")
    p = str(tmp_path / "n.dsn")
    s.export_dsn(p, cell_name="TOP")
    txt = open(p).read()
    assert "(layer L5 (type signal)" in txt                     # fingers on L5 force two layers
    assert txt.count("(pin PAD_L5_400x400 B") == 22
    assert "(pin PAD_L3_400x400 B" not in txt
    ses = tmp_path / "n.ses"
    ses.write_text("(session n (routes (resolution um 1) (network_out)))\n")
    top = s.library.cells["TOP"]
    before = sum(isinstance(x, Rectangle) and x.layer == 5 for x in top.shapes)
    out = s.import_ses(str(ses), cell_name="TOP")
    assert out["fingers"] == 22
    assert sum(isinstance(x, Rectangle) and x.layer == 5 for x in top.shapes) - before == 22
    # an explicit one-layer route keeps them on the 1st conductor
    s.set_freerouting_rules(layer_mode="single")
    s.export_dsn(p, cell_name="TOP")
    assert open(p).read().count("(pin PAD_L3_400x400 B") == 22


# --- track directions per layer + the via-optimisation pass -----------------

def _autoroute_scope(txt):
    i = txt.index("(autoroute_settings")
    depth = 0
    for j in range(i, len(txt)):
        depth += {"(": 1, ")": -1}.get(txt[j], 0)
        if depth == 0:
            return txt[i:j + 1]
    raise AssertionError("unbalanced autoroute_settings")


def test_dsn_sets_a_preferred_direction_per_layer(tmp_path):
    s = _named()
    p = str(tmp_path / "d.dsn")
    s.export_dsn(p, layer_mode="two")                   # default: 1st conductor horizontal
    sc = _autoroute_scope(open(p).read())
    assert "(autoroute on)" in sc and "(vias on)" in sc and "(via_costs 50)" in sc
    assert "(layer_rule L3 (active on) (preferred_direction horizontal)" in sc
    assert "(layer_rule L5 (active on) (preferred_direction vertical)" in sc
    assert "(against_preferred_direction_trace_costs 3)" in sc
    s.export_dsn(p, layer_mode="two", layer_directions="vh", against_direction_cost=5,
                 via_cost=80)
    sc = _autoroute_scope(open(p).read())
    assert "(layer_rule L3 (active on) (preferred_direction vertical)" in sc
    assert "(layer_rule L5 (active on) (preferred_direction horizontal)" in sc
    assert "(against_preferred_direction_trace_costs 5)" in sc and "(via_costs 80)" in sc
    assert open(p).read().count("(") == open(p).read().count(")")


def test_no_autoroute_settings_when_directions_are_off(tmp_path):
    s = _named()
    p = str(tmp_path / "o.dsn")
    s.export_dsn(p, layer_mode="two", layer_directions="off")
    assert "autoroute_settings" not in open(p).read()      # Freerouting's own defaults


def test_single_layer_route_has_no_directions(tmp_path):
    s = _named()
    p = str(tmp_path / "s.dsn")
    s.export_dsn(p, layer_mode="single")
    assert "layer_rule" not in open(p).read()


def test_freeroute_runs_route_then_an_optimise_only_via_pass():
    s = _named()
    R = s.freerouting_rules()
    R.update(layer_mode="two", via_optimize=True, optimize_passes=40, via_optimize_cost=250)
    (t1, r1, o1), (t2, r2, o2) = s.freeroute_stages(R)
    assert (t1, o1, r1["_autoroute"], r1["_postroute"]) == ("", 0, True, False)
    assert (t2, o2, r2["_autoroute"], r2["_postroute"]) == ("_vias", 40, False, True)
    assert r2["via_cost"] == 250 and r2["keep_existing"] is False   # the optimiser may move them
    cmd = s.freeroute_command("freerouting.exe", "a.dsn", "a.ses", r2, o2)
    assert "--router.autorouter.enabled=false" in cmd and "--router.fanout.enabled=false" in cmd
    assert "--router.optimizer.max_passes=40" in cmd
    cmd = s.freeroute_command("freerouting.exe", "a.dsn", "a.ses", r1, o1)
    assert "--router.optimizer.enabled=false" in cmd and "--router.autorouter.enabled=false" not in cmd
    # one plain run when via optimisation is off, or there's no optimising, or one layer
    for kw in ({"via_optimize": False}, {"optimize_passes": 0}, {"layer_mode": "single"}):
        assert len(s.freeroute_stages(dict(R, **kw))) == 1


def test_via_pass_dsn_says_optimise_only(tmp_path):
    s = _named()
    R = s.freerouting_rules()
    R.update(layer_mode="two", via_optimize=True, optimize_passes=10)
    _t, r2, _o = s.freeroute_stages(R)[1]
    p = str(tmp_path / "v.dsn")
    s.export_dsn(p, **r2)
    sc = _autoroute_scope(open(p).read())
    assert "(autoroute off) (postroute on)" in sc and "(via_costs 200)" in sc
    assert "(type route)" in open(p).read() and "(type protect)" not in open(p).read()
